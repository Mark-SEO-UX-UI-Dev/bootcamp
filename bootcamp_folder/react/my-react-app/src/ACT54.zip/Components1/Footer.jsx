import React, { Component1 } from "react";

class Footer extends Component1 {
  render() {
    return (
      <>
        <footer>
          <div class="container">
            <div class="row text-center bg-dark text-light">
              <div class="col-lg-12">
                <p>09123456789 | Mark Anthony Tan</p>
              </div>
            </div>
          </div>
        </footer>
      </>
    );
  }
}

export default Footer;
