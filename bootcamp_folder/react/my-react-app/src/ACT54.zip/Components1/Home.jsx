import { Component1 } from "react";
import "../css1/styles.css";

class Home extends Component1 {
  render() {
    return (
      <>
        <div class="container home">
          <div class="row text-center">
            <span
              class="background-image"
              role="img"
              aria-label="Cheeseburger and Fries"
            >
              {" "}
            </span>
            <h1 class="text-dark fw-bold">Home page</h1>
            <a href="./ordering" class="btn btn-primary">
              Order Now
            </a>
          </div>
        </div>
      </>
    );
  }
}

export default Home;
