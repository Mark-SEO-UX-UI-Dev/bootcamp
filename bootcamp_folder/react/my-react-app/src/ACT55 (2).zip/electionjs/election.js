import Election from "javascript";

export function checkboxlimit() {
  alert("You can only select a maximum of " + limit + " checkboxes");
}
}
