const pet_store = [
  { id: 0, species: "Dog", breed: "German Shepherd", name: "Strongie" },
  { id: 1, species: "Dog", breed: "American Eskimo Dog", name: "Pogi" },
  { id: 2, species: "Cat", breed: "Persian Cat", name: "Kulit" },
  { id: 3, species: "Cat", breed: "Birman", name: "Cutie" },
  { id: 4, species: "Bird", breed: "Sun Conure", name: "Birdie" },
  { id: 5, species: "Bird", breed: "Budgerigar", name: "Anna" },
  { id: 6, species: "Rabbit", breed: "American Fuzzy Lop", name: "Rara" },
  { id: 7, species: "Rabbit", breed: "Angora Rabbit", name: "Bibit" },
  { id: 8, species: "Fish", breed: "Harlequin Tuskfish", name: "KoiKoi" },
  { id: 9, species: "Fish", breed: "Clownfish", name: "Nemo" },
  { id: 10, species: "Horse", breed: "Friesian Horse", name: "Blacky" },
  { id: 11, species: "Horse", breed: "Boulonnais Horse", name: "Pretty" },
];

module.exports = { pet_store };
